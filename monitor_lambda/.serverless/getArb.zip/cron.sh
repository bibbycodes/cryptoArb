export NODE_ENV=development
export DB_NAME=crypto_arb
export DB_USER_LOCAL=bibbycodes
export DB_PASS=afriex2020
export DB_HOST=crypto-arb.c3nrbcecxqrn.eu-west-2.rds.amazonaws.com
export API_KEY=58d424bdd71e14033e0f880c98e994fb
export BN_KEY=7KdXDvhS35ZvHez9D7522pgQuN9fRqzHO4Te4OFK1v4Jmt4x27aIvnQQ1pMPycZJ
export BN_SECRET=Og8ObTOic9bpP9yfwDAimWmJO7Ver1rKkpRUsDtYV9Qgt3cqrahHf8chThpSOmaI
export MAIL_URL=mg.afriex.co

/usr/local/bin/node ~/Documents/Projects/cryptoArb/monitor_lambda/getArb.js