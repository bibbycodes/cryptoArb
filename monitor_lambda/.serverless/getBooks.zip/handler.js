exports.getBooks = require('./getBooks').func;
